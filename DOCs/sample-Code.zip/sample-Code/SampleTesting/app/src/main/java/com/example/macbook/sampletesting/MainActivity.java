package com.example.macbook.sampletesting;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.macbook.qpaysdk.OrderInfo;
import com.example.macbook.qpaysdk.PaymentProcessing;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText amountET = (EditText) findViewById(R.id.amount);
        Button pay = (Button) findViewById(R.id.payHere);

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                OrderInfo orderInfo = new OrderInfo();
                String orderAmount = "10";

                byte[] byt = new byte[0];
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
                    byt = orderAmount.getBytes(StandardCharsets.US_ASCII);
                }
                String qpayId = "Your QPay Id" + "`" + new String(Base64.encodeToString(byt, Base64.DEFAULT));

                OrderInfo objOrderInfo = new OrderInfo();

                objOrderInfo.setMode("test");
                objOrderInfo.setQpayID(qpayId);
                objOrderInfo.setQpayPWD("Your QPay Password");

                // Enter Your Unique Order ID.
                objOrderInfo.setOrderID(UUID.randomUUID().toString().replace("-", "").substring(0, 16));
                objOrderInfo.setCurrencyCode("INR");
                objOrderInfo.setPaymentOption("C,D,U");
                objOrderInfo.setResponseActivity("com.example.macbook.sampletesting.ResponseActivity");



                objOrderInfo.setName("John doe");
                objOrderInfo.setAddress("6th Cross Street");
                objOrderInfo.setCity("Chennai");
                objOrderInfo.setState("Tamil Nadu");
                objOrderInfo.setCountry("India");
                objOrderInfo.setPostal_code("600020");
                objOrderInfo.setPhone("9940620019");
                objOrderInfo.setEmail("app@qpayindia.com");

                Intent i = new Intent(getApplicationContext(), PaymentProcessing.class);
                i.putExtra("OrderInfo", objOrderInfo);
                startActivity(i);
                finish();
            }
        });


    }
}
